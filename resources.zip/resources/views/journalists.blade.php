<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>JournalistxEdu</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
Route::view('journalists');
<div id="page-container">
    <div id="content-wrap">
        <div id="header">
            <img id="logo" src = "brand.png" alt="JournalistxEdu logo" width=120px>
            <h1>JournalistxEdu</h1>
        </div>

        <div class = "menu-bar">
            <a href="index.html">Home</a>
            <a href="about.html">About</a>
            <a href="students.html">Students</a>
            <a class="active" href="journalists.html">Journalists</a>
            <a href="publishedworks.html">Published Works</a>
        </div>

        <div id="apply">
            <a class="button" href="apply.html">APPLY</a>
        </div>
        <div id="login">
            <a class="button" href="login.html">LOGIN</a>
        </div>
        <div id="description">
            <img id="image" src="journalists-image.jpg" alt="a typewriter" width=300>
            <p id="text">Out-of-work journalists looking to find meaningful work are invited to apply for a mentorship <br>position through JournalistxEdu. Accepted mentors will work with up to ten students <br>over a semester-long period and will recieve a stipend as compensation for sharing their expertise.<br>
                A list of benchmarks that students are expected to reach will be provided <br>to mentors as a guide for them in creating a mini-curriculum. Mentors are encouraged <br>to structure their lessons around the disciplines they are most passionate <br>about. Weekly meetings with students, lesson plans, and writing thoughtful feedback will <br>comprise the time commitment. </p></div>
        <div>
            <footer id="footer"> </footer>
        </div>
    </div>
</body>
</html>
